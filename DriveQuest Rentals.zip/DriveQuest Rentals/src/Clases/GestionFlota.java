package Clases;

import Interfaces.CalculoBoleta;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class GestionFlota {
    private List<Vehiculo> flotaVehiculos;
    private Map<String, Vehiculo> vehiculosPorPatente;
    private static final String NOMBRE_ARCHIVO = "vehiculos.txt";

    public GestionFlota() {
        this.flotaVehiculos = new ArrayList<>();
        this.vehiculosPorPatente = new HashMap<>();
        cargarVehiculos();
    }
    
    public synchronized boolean agregarVehiculo(Vehiculo vehiculo) {
        if (vehiculosPorPatente.containsKey(vehiculo.getPatente().toUpperCase())) {
            System.out.println("Error: Ya existe un vehiculo con la patente " + vehiculo.getPatente() + ".");
            return false;
        }
        flotaVehiculos.add(vehiculo);
        vehiculosPorPatente.put(vehiculo.getPatente().toUpperCase(), vehiculo);
        System.out.println("Vehículo con patente " + vehiculo.getPatente() + " agregado exitosamente.");
        guardarVehiculos();
        return true;
    }

    public synchronized List<Vehiculo> listarVehiculos() {
        if (flotaVehiculos.isEmpty()) {
            System.out.println("\nLa flota de vehiculos esta vacia.");
        }
        System.out.println("\n--- Listado de Vehiculos en la Flota ---");
        for (Vehiculo vehiculo : flotaVehiculos) {
            vehiculo.mostrarDatos();
            System.out.println("--------------------------------------");
        }
        return new ArrayList<>(flotaVehiculos);
    }

    public synchronized List<Vehiculo> obtenerVehiculosArriendoLargo() {
        List<Vehiculo> arriendosLargos = new ArrayList<>();
        System.out.println("\n--- Vehiculos con Arriendos de 7 o Mas Dias ---");
        if (flotaVehiculos.isEmpty()) {
            System.out.println("La flota de vehiculos esta vacia, no hay arriendos largos.");
            return arriendosLargos;
        }

        boolean encontrado = false;
        for (Vehiculo vehiculo : flotaVehiculos) {
            if (vehiculo.getDiasArrendado() >= 7) {
                vehiculo.mostrarDatos();
                arriendosLargos.add(vehiculo);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron vehiculos con arriendos de 7 o mas dias.");
        }
        System.out.println("---------------------------------------------");
        return arriendosLargos;
    }

    public void guardarVehiculos() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(NOMBRE_ARCHIVO))) {
            for (Vehiculo vehiculo : flotaVehiculos) {
                if (vehiculo instanceof VehiculoCarga) {
                    VehiculoCarga vc = (VehiculoCarga) vehiculo;
                    writer.println("C;" + vc.getPatente() + ";" + vc.getMarca() + ";" + vc.getModelo() + ";" +
                                   vc.getAno() + ";" + vc.getPrecioArriendoPorDia() + ";" + vc.getDiasArrendado() + ";" +
                                   vc.getCapacidadCarga());
                } else if (vehiculo instanceof VehiculoParticular) {
                    VehiculoParticular vp = (VehiculoParticular) vehiculo;
                    writer.println("P;" + vp.getPatente() + ";" + vp.getMarca() + ";" + vp.getModelo() + ";" +
                                   vp.getAno() + ";" + vp.getPrecioArriendoPorDia() + ";" + vp.getDiasArrendado() + ";" +
                                   vp.getNumeroMaxPasajeros());
                }
            }
            System.out.println("Datos de vehiculos guardados en " + NOMBRE_ARCHIVO);
        } catch (IOException e) {
            System.err.println("Error al guardar los vehiculos: " + e.getMessage());
        }
    }

    public void cargarVehiculos() {
        flotaVehiculos.clear();
        vehiculosPorPatente.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(NOMBRE_ARCHIVO))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(";");
                try {
                    String tipo = partes[0];
                    String patente = partes[1];
                    String marca = partes[2];
                    String modelo = partes[3];
                    int ano = Integer.parseInt(partes[4]);
                    double precioArriendoPorDia = Double.parseDouble(partes[5]);
                    int diasArrendado = Integer.parseInt(partes[6]);

                    Vehiculo nuevoVehiculo = null;
                    if (tipo.equalsIgnoreCase("C")) {
                        double capacidadCarga = Double.parseDouble(partes[7]);
                        nuevoVehiculo = new VehiculoCarga(patente, marca, modelo, ano, precioArriendoPorDia, diasArrendado, capacidadCarga);
                    } else if (tipo.equalsIgnoreCase("P")) {
                        int numeroMaxPasajeros = Integer.parseInt(partes[7]);
                        nuevoVehiculo = new VehiculoParticular(patente, marca, modelo, ano, precioArriendoPorDia, diasArrendado, numeroMaxPasajeros);
                    }

                    if (nuevoVehiculo != null) {
                        flotaVehiculos.add(nuevoVehiculo);
                        vehiculosPorPatente.put(nuevoVehiculo.getPatente().toUpperCase(), nuevoVehiculo);
                    }

                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.err.println("Error de formato en la linea del archivo: " + linea + ". Detalles: " + e.getMessage());
                }
            }
            System.out.println("Vehiculos cargados desde " + NOMBRE_ARCHIVO);
        } catch (IOException e) {
            System.err.println("No se pudo cargar el archivo de vehiculos (quizas no existe aun): " + e.getMessage());
        }
    }
    public synchronized Vehiculo buscarVehiculoPorPatente(String patente) {
        return vehiculosPorPatente.get(patente.toUpperCase());
    }
}