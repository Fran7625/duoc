package Clases;
public class TareaValidacionFlota extends Thread {
    private GestionFlota gestionFlota;
    private String nombreTarea;

    public TareaValidacionFlota(String nombreTarea, GestionFlota gestionFlota) {
        this.nombreTarea = nombreTarea;
        this.gestionFlota = gestionFlota;
    }

    @Override
    public void run() {
        System.out.println("Iniciando tarea concurrente: " + nombreTarea);
        try {
            synchronized (gestionFlota) {
                System.out.println(nombreTarea + ": Accediendo a la flota para validacion...");
                gestionFlota.listarVehiculos();
                Thread.sleep(2000);
                System.out.println(nombreTarea + ": Validacion completada.");
            }
        } catch (InterruptedException e) {
            System.err.println(nombreTarea + ": Tarea interrumpida." + e.getMessage());
            Thread.currentThread().interrupt();
        }
        System.out.println("Finalizando tarea concurrente: " + nombreTarea);
    }
}