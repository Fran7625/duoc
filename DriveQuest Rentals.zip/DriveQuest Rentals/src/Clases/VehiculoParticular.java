package Clases;
import Interfaces.CalculoBoleta;

public class VehiculoParticular extends Vehiculo implements CalculoBoleta {
    private int numeroMaxPasajeros;

    public VehiculoParticular() {
        super();
    }

    public VehiculoParticular(String patente, String marca, String modelo, int ano, double precioArriendoPorDia, int diasArrendado, int numeroMaxPasajeros) {
        super(patente, marca, modelo, ano, precioArriendoPorDia, diasArrendado);
        this.numeroMaxPasajeros = numeroMaxPasajeros;
    }

    public int getNumeroMaxPasajeros() {
        return numeroMaxPasajeros;
    }

    public void setNumeroMaxPasajeros(int numeroMaxPasajeros) {
        this.numeroMaxPasajeros = numeroMaxPasajeros;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("--- Datos de Vehiculo de Pasajeros ---");
        System.out.println("Patente: " + getPatente());
        System.out.println("Marca: " + getMarca());
        System.out.println("Modelo: " + getModelo());
        System.out.println("Year: " + getAno());
        System.out.println("Precio Arriendo por Dia: $" + getPrecioArriendoPorDia());
        System.out.println("Dias Arrendado: " + getDiasArrendado());
        System.out.println("Nimero Maximo de Pasajeros: " + numeroMaxPasajeros);
        System.out.println("-------------------------------------");
    }

    @Override
    public void calcularBoleta(Vehiculo vehiculo) {
        if (!(vehiculo instanceof VehiculoParticular)) {
            System.out.println("Error: El vehiculo proporcionado no es un vehiculo de pasajeros.");
            return;
        }

        double subtotal = vehiculo.getPrecioArriendoPorDia() * vehiculo.getDiasArrendado();
        double descuentoMonto = subtotal * CalculoBoleta.DESCUENTO_PASAJEROS;
        double subtotalConDescuento = subtotal - descuentoMonto;
        double ivaMonto = subtotalConDescuento * CalculoBoleta.IVA;
        double totalPagar = subtotalConDescuento + ivaMonto;

        System.out.println("\n--- Detalle Boleta Arriendo Vehiculo de Pasajeros ---");
        System.out.println("Patente: " + vehiculo.getPatente());
        System.out.println("Dias Arrendados: " + vehiculo.getDiasArrendado());
        System.out.println("Precio por Dia: $" + String.format("%.2f", vehiculo.getPrecioArriendoPorDia()));
        System.out.println("Subtotal (sin descuento): $" + String.format("%.2f", subtotal));
        System.out.println("Descuento (" + (CalculoBoleta.DESCUENTO_PASAJEROS * 100) + "%): $" + String.format("%.2f", descuentoMonto));
        System.out.println("Subtotal con Descuento: $" + String.format("%.2f", subtotalConDescuento));
        System.out.println("IVA (" + (CalculoBoleta.IVA * 100) + "%): $" + String.format("%.2f", ivaMonto));
        System.out.println("Total a Pagar: $" + String.format("%.2f", totalPagar));
        System.out.println("-------------------------------------------------------");
    }
}