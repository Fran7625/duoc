package Clases;

public abstract class Vehiculo {
    private String patente;
    private String marca;
    private String modelo;
    private int ano;
    private double precioArriendoPorDia;
    private int diasArrendado;

    public Vehiculo() {
    }

    public Vehiculo(String patente, String marca, String modelo, int ano, double precioArriendoPorDia, int diasArrendado) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.precioArriendoPorDia = precioArriendoPorDia;
        this.diasArrendado = diasArrendado;
    }

    public String getPatente() {
        return patente;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getAno() {
        return ano;
    }

    public double getPrecioArriendoPorDia() {
        return precioArriendoPorDia;
    }

    public int getDiasArrendado() {
        return diasArrendado;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setPrecioArriendoPorDia(double precioArriendoPorDia) {
        this.precioArriendoPorDia = precioArriendoPorDia;
    }

    public void setDiasArrendado(int diasArrendado) {
        this.diasArrendado = diasArrendado;
    }
    
    public abstract void mostrarDatos();
}