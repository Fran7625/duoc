package main;

import Clases.GestionFlota;
import Clases.Vehiculo;
import Clases.VehiculoCarga;
import Clases.VehiculoParticular;
import Clases.TareaValidacionFlota;
import Interfaces.CalculoBoleta;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static GestionFlota miFlota = new GestionFlota();
    public static void main(String[] args) {
        System.out.println("--- Iniciando tareas concurrentes en segundo plano ---");
        TareaValidacionFlota tarea1 = new TareaValidacionFlota("Validador-1", miFlota);
        TareaValidacionFlota tarea2 = new TareaValidacionFlota("Validador-2", miFlota);
        tarea1.start();
        tarea2.start();
        try {
            System.out.println("\nEsperando a que las tareas concurrentes terminen su primera ejecucion...");
            tarea1.join();
            tarea2.join();
            System.out.println("Tareas concurrentes iniciales finalizadas. Procediendo al menu principal.");
        } catch (InterruptedException e) {
            System.err.println("Error al esperar a las tareas concurrentes: " + e.getMessage());
            Thread.currentThread().interrupt();
        }
        System.out.println("\n--- Verificando y añadiendo vehiculos de ejemplo (si la flota esta vacia) ---");
        if (miFlota.listarVehiculos().isEmpty()) {
            System.out.println("La flota esta vacia, añadiendo vehiculos de ejemplo.");
            miFlota.agregarVehiculo(new VehiculoCarga("ABCD12", "Ford", "F-150", 2020, 60000.0, 8, 3.0));
            miFlota.agregarVehiculo(new VehiculoParticular("EFGH34", "Toyota", "Corolla", 2022, 40000.0, 5, 5));
            miFlota.agregarVehiculo(new VehiculoCarga("IJKL56", "Mercedes", "Sprinter", 2021, 70000.0, 10, 4.5));
            miFlota.agregarVehiculo(new VehiculoParticular("MNOP78", "Nissan", "Versa", 2019, 35000.0, 7, 4));
        } else {
            System.out.println("La flota ya contiene vehiculos cargados o agregados previamente.");
        }
        int opcion;
        do {
            mostrarMenu();
            opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    agregarVehiculoConsola();
                    break;
                case 2:
                    miFlota.listarVehiculos();
                    break;
                case 3:
                    mostrarBoletaConsola();
                    break;
                case 4:
                    miFlota.obtenerVehiculosArriendoLargo();
                    break;
                case 5:
                    System.out.println("Saliendo del programa. Chau");
                    break;
                default:
                    System.out.println("Opcion no valida. Por favor, intente de nuevo.");
                    break;
            }
            if (opcion != 5) {
                System.out.println("\nPresiona Enter para continuar.");
                scanner.nextLine();
            }

        } while (opcion != 5);

        scanner.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n--- Sistema de Gestion de Flota ---");
        System.out.println("1. Agregar Vehiculo");
        System.out.println("2. Listar Todos los Vehiculos");
        System.out.println("3. Mostrar Boleta de Arriendo (por patente)");
        System.out.println("4. Ver Vehiculos con Arriendo Largo (>= 7 dias)");
        System.out.println("5. Salir");
        System.out.print("Ingrese su opcion: ");
    }

    private static int leerOpcion() {
        int opcion = -1;
        String lineaInput = scanner.nextLine();
        try {
            opcion = Integer.parseInt(lineaInput.trim());
        } catch (NumberFormatException e) {
            System.out.println("Entrada invalida. Por favor, ingrese un numero.");
        }
        return opcion;
    }

    private static void agregarVehiculoConsola() {
        System.out.println("\n--- Agregar Nuevo Vehiculo ---");
        System.out.print("Tipo de Vehiculo (C: Carga / P: Particular): ");
        String tipo = scanner.nextLine();

        System.out.print("Patente: ");
        String patente = scanner.nextLine();
        System.out.print("Marca: ");
        String marca = scanner.nextLine();
        System.out.print("Modelo: ");
        String modelo = scanner.nextLine();

        int ano = 0;
        double precioArriendoPorDia = 0.0;
        int diasArrendado = 0;
        try {
            System.out.print("Year: ");
            ano = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Precio de Arriendo por Dia: ");
            precioArriendoPorDia = Double.parseDouble(scanner.nextLine().trim());

            System.out.print("Dias Arrendado: ");
            diasArrendado = Integer.parseInt(scanner.nextLine().trim());

        } catch (NumberFormatException e) {
            System.out.println("Error: Ingreso invalido para campos numericos. Asegurate de usar numeros.");
            return;
        }

        Vehiculo nuevoVehiculo = null;

        if (tipo.equalsIgnoreCase("C")) {
            double capacidadCarga = 0.0;
            try {
                System.out.print("Capacidad de Carga (toneladas): ");
                capacidadCarga = Double.parseDouble(scanner.nextLine().trim());
                nuevoVehiculo = new VehiculoCarga(patente, marca, modelo, ano, precioArriendoPorDia, diasArrendado, capacidadCarga);
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingreso invalido para Capacidad de Carga. Debe ser un numero.");
                return;
            }
        } else if (tipo.equalsIgnoreCase("P")) {
            int numPasajeros = 0;
            try {
                System.out.print("Numero Maximo de Pasajeros: ");
                numPasajeros = Integer.parseInt(scanner.nextLine().trim());
                nuevoVehiculo = new VehiculoParticular(patente, marca, modelo, ano, precioArriendoPorDia, diasArrendado, numPasajeros);
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingreso invalido para Numero Maximo de Pasajeros. Debe ser un numero entero.");
                return;
            }
        } else {
            System.out.println("Tipo de vehIculo no reconocido. Intente 'C' para Carga o 'P' para Particular.");
            return;
        }
        if (nuevoVehiculo != null) {
            miFlota.agregarVehiculo(nuevoVehiculo);
        }
    }
    private static void mostrarBoletaConsola() {
        System.out.println("\n--- Mostrar Boleta de Arriendo ---");
        System.out.print("Ingrese la patente del vehiculo para ver su boleta: ");
        String patente = scanner.nextLine();

        Vehiculo vehiculoEncontrado = miFlota.buscarVehiculoPorPatente(patente);

        if (vehiculoEncontrado != null) {
            if (vehiculoEncontrado instanceof CalculoBoleta) {
                ((CalculoBoleta) vehiculoEncontrado).calcularBoleta(vehiculoEncontrado);
            } else {
                System.out.println("El vehiculo encontrado no puede calcular boletas (no implementa CalculoBoleta).");
            }
        } else {
            System.out.println("Vehiculo con patente " + patente + " no encontrado.");
        }
    }
}