package clases;

import java.util.concurrent.BlockingQueue;

public class GeneradorHilos implements Runnable {
    private final BlockingQueue<Integer> cola;
    private final int rangoInicio;
    private final int rangoFinal;

    public GeneradorHilos(BlockingQueue<Integer> cola, int start, int end) {
        this.cola = cola;
        this.rangoInicio = start;
        this.rangoFinal = end;
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " produciendo numeros desde " + rangoInicio + " hasta " + rangoFinal);
        for (int i = rangoInicio; i <= rangoFinal; i++) {
            try {
                cola.put(i);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Productor interrumpido: " + e.getMessage());
                break;
            }
        }
        System.out.println(Thread.currentThread().getName() + " ha finalizado la producción.");
    }
}