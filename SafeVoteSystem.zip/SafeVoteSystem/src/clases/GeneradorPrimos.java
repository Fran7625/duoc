package clases;

public class GeneradorPrimos implements Runnable {
    private ListaPrimos listaPrimos;
    private int rangoInicio;
    private int rangoFinal;

    public GeneradorPrimos(ListaPrimos list, int start, int end) {
        this.listaPrimos = list;
        this.rangoInicio = start;
        this.rangoFinal = end;
    }
     @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " buscando primos desde " + rangoInicio + " hasta " + rangoFinal);
        for (int i = rangoInicio; i <= rangoFinal; i++) {
            try {
                listaPrimos.add(i); 
            } catch (IllegalArgumentException e) {
            }
        }
        System.out.println(Thread.currentThread().getName() + " ha finalizado.");
    }
}