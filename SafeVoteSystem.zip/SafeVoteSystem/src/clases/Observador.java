package clases;
import Interfaz.NotificadorPrimo;

public class Observador implements NotificadorPrimo {
    @Override
    public void primoAgregado(int numeroPrimo) {
        System.out.println(" Nuevo primo agregado a la lista: " + numeroPrimo);
    }
}