package clases;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ManejoArchivos {

   public void loadPrimesFromCSV(String votos, ListaPrimos listaPrimos) {
        System.out.println("Intentando cargar primos desde: " + votos);
        try (BufferedReader br = new BufferedReader(new FileReader(votos))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] numeros = linea.split(",");
                for (String numberStr : numeros) {
                    try {
                        int candidatoPrimo = Integer.parseInt(numberStr.trim());
                        synchronized (listaPrimos) {
                            listaPrimos.add(candidatoPrimo);
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Advertencia: Error al parsear el numero '" + numberStr.trim() + "' en " + votos + ". Se ignorara. Mensaje: " + e.getMessage());
                    } catch (IllegalArgumentException e) {
                        System.err.println("Advertencia: No se pudo agregar '" + numberStr.trim() + "' a la lista de primos desde " + votos + ". Mensaje: " + e.getMessage());
                    }
                }
            }
            System.out.println("Carga de numeros desde " + votos + " completada.");
        } catch (IOException e) {
            System.err.println("Error al leer el archivo CSV '" + votos + "': " + e.getMessage());
        }
    }
    public void writeEncryptedMessages(String conteovotos, String mensajeEncriptado, List<Integer> primosUsados) {
        System.out.println("Intentando escribir en: " + conteovotos);
        try (FileWriter fw = new FileWriter(conteovotos, true)) {
            fw.write("--- Nuevo Registro ---\n");
            fw.write("Fecha y Hora: " + new java.util.Date() + "\n");
            fw.write("Mensaje Encriptado: " + mensajeEncriptado + "\n");
            fw.write("Codigos Primos Utilizados (" + primosUsados.size() + "): " + primosUsados.toString() + "\n");
            fw.write("----------------------\n\n");
            System.out.println("Mensaje encriptado y codigos primos escritos en " + conteovotos + " con exito.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo de texto '" + conteovotos + "': " + e.getMessage());
        }
    }
}