package clases;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;

public class VerificadorHilos implements Runnable {
    private final BlockingQueue<Integer> cola;
    private final ListaPrimos listaPrimos;
    private final CountDownLatch latch;

    public VerificadorHilos(BlockingQueue<Integer> cola, ListaPrimos listaPrimos, CountDownLatch latch) {
        this.cola = cola;
        this.listaPrimos = listaPrimos;
        this.latch = latch;
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " iniciando consumo de numeros.");
        try {
            while (true) {
                Integer numero = cola.take();
                if (numero == -1) {
                    cola.put(numero);
                    break;
                }
                try {
                    listaPrimos.add(numero);
                } catch (IllegalArgumentException e) {
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Consumidor interrumpido: " + e.getMessage());
        } finally {
            latch.countDown();
            System.out.println(Thread.currentThread().getName() + " ha finalizado el consumo.");
        }
    }
}