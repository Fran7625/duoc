package clases;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import Interfaz.NotificadorPrimo;

public class ListaPrimos extends ArrayList<Integer> {
    private final List<NotificadorPrimo> listeners = new ArrayList<>();

    private boolean isPrime(int n){
        if (n <2) return false;
        
        for (int y = 2; y <= Math.sqrt(n); y++){
            if (n % y == 0) return false;
        }
        return true;   
    }
    public synchronized void addListener(NotificadorPrimo listener) {
        listeners.add(listener);
    }
    private void notifyPrimeAdded(int numeroPrimo) {
        for (NotificadorPrimo listener : listeners) {
            listener.primoAgregado(numeroPrimo);
        }
    }
    @Override
    public synchronized boolean add(Integer e) {
        if (!isPrime(e)) {
            throw new IllegalArgumentException("Solo se pueden agregar numeros primos a la lista.");
        }
        boolean added = super.add(e);
        if (added) {
            notifyPrimeAdded(e);
        }
        return added;
    }
    @Override
    public synchronized void add(int index, Integer element) {
        if (!isPrime(element)) {
            throw new IllegalArgumentException("Solo se pueden agregar numeros primos a la lista.");
        }
        super.add(index, element);
        notifyPrimeAdded(element);
    }
    @Override
    public synchronized boolean addAll(Collection<? extends Integer> c) {
        boolean changed = false;
        for (Integer num : c) {
            if (!isPrime(num)) {
                throw new IllegalArgumentException("Solo se pueden agregar numeros primos a la lista. Se intento agregar un numero no primo a la lista.");
            }
        }
        for (Integer num : c) {
            if (super.add(num)) {
                notifyPrimeAdded(num);
                changed = true;
            }
        }
        return changed;
    }
    @Override
    public synchronized boolean addAll(int index, Collection<? extends Integer> c) {
        for (Integer num : c) {
            if (!isPrime(num)) {
                throw new IllegalArgumentException("Solo se pueden agregar numeros primos a la lista. Se intento agregar un numero no primo a la lista.");
            }
        }
        boolean changed = false;
        int currentIdx = index;
        for (Integer num : c) {
            super.add(currentIdx++, num);
            notifyPrimeAdded(num);
            changed = true;
        }
        return changed;
    }
    @Override
    public synchronized boolean remove(Object o) {
        return super.remove(o);
    }
    @Override
    public synchronized Integer remove(int index) {
        return super.remove(index);
    }
    public int getPrimesCount() {
        return size();
    }
    @Override
    public synchronized void clear() {
        super.clear();
    }
}