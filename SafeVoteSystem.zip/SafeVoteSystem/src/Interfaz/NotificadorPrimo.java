package Interfaz;

public interface NotificadorPrimo {
    void primoAgregado(int numeroPrimo);
}
