package Main;

import clases.ManejoArchivos;
import clases.GeneradorPrimos;
import clases.ListaPrimos;
import clases.GeneradorHilos;
import clases.VerificadorHilos;
import clases.Observador;
import Interfaz.NotificadorPrimo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;

public class SafeVoteSystem {

    public static void main(String[] args) {
        System.out.println("--- INICIO DE LA APLICACION SAFE VOTE SYSTEM ---");
        ListaPrimos listaPrimos = new ListaPrimos();
        ManejoArchivos manejoArchivos = new ManejoArchivos();
        System.out.println("\n--- Realizando Pruebas Unitarias para PrimesList ---");
        try {
            System.out.println("Prueba 1: Agregando numeros primos (2, 3, 5)...");
            listaPrimos.add(2);
            listaPrimos.add(3);
            listaPrimos.add(5);
            System.out.println("Prueba 1 EXITO: Primos agregados. Cantidad actual: " + listaPrimos.getPrimesCount());
            System.out.println("Elementos en lista: " + listaPrimos);
        } catch (IllegalArgumentException e) {
            System.err.println("Prueba 1 FALLO: Error inesperado al agregar primos: " + e.getMessage());
        }
        try {
            System.out.println("\nPrueba 2: Intentando agregar numero no primo (4)...");
            listaPrimos.add(4);
            System.err.println("Prueba 2 FALLO: Se agrego un numero no primo inesperadamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Prueba 2 EXITO: Se capturo correctamente la excepcion al intentar agregar un no primo: " + e.getMessage());
        }
        try {
            System.out.println("\nPrueba 3: Removiendo el numero 3...");
            if (listaPrimos.remove(Integer.valueOf(3))) {
                System.out.println("Prueba 3 EXITO: Numero 3 removido. Cantidad actual: " + listaPrimos.getPrimesCount());
                System.out.println("Elementos en lista: " + listaPrimos);
            } else {
                System.err.println("Prueba 3 FALLO: No se pudo remover el número 3.");
            }
        } catch (Exception e) {
            System.err.println("Prueba 3 FALLO: Error inesperado al remover: " + e.getMessage());
        }
        try {
            System.out.println("\nPrueba 4: Agregando una coleccion de primos (7, 11)...");
            listaPrimos.addAll(Arrays.asList(7, 11));
            System.out.println("Prueba 4 EXITO: Coleccion de primos agregada. Cantidad actual: " + listaPrimos.getPrimesCount());
            System.out.println("Elementos en lista: " + listaPrimos);
        } catch (IllegalArgumentException e) {
            System.err.println("Prueba 4 FALLO: Error inesperado al agregar coleccion de primos: " + e.getMessage());
        }
        try {
            System.out.println("\nPrueba 5: Intentando agregar una coleccion con no primos (13, 14)...");
            listaPrimos.addAll(Arrays.asList(13, 14));
            System.err.println("Prueba 5 FALLO: Se agrego una coleccion con un no primo inesperadamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Prueba 5 EXITO: Se capturo correctamente la excepcion al intentar agregar coleccion con no primo: " + e.getMessage());
        }
        System.out.println("\n--- Fin de Pruebas Unitarias para PrimesList ---");
        listaPrimos.clear();
        System.out.println("\n--- Realizando Pruebas de Interaccion con Archivos ---");
        String csvFilePath = "src/main/votos.csv";
        String logFilePath = "src/main/conteovotos.txt";
        System.out.println("\nPrueba 6: Cargando primos desde CSV...");
        manejoArchivos.loadPrimesFromCSV(csvFilePath, listaPrimos);
        System.out.println("Prueba 6: Cantidad de primos cargados desde CSV: " + listaPrimos.getPrimesCount());
        System.out.println("Primos actuales en lista: " + listaPrimos);
        System.out.println("\nPrueba 7: Escribiendo mensaje encriptado en log...");
        List<Integer> primesForMessageLog = new ArrayList<>();
        int countForLog = 0;
        for (Integer prime : listaPrimos) {
            if (countForLog < 20) {
                primesForMessageLog.add(prime);
                countForLog++;
            } else {
                break;
            }
        }
        manejoArchivos.writeEncryptedMessages(logFilePath, "Voto_Presidencial_2025", primesForMessageLog);
        System.out.println("\n--- Fin de Pruebas de Interaccion con Archivos ---");
        listaPrimos.clear(); 
        
        System.out.println("\n--- Iniciando Generacion de Primos con Queue y Topic ---");
        listaPrimos.addListener(new Observador());
        BlockingQueue<Integer> numbersToVerifyQueue = new ArrayBlockingQueue<>(1000);
        int numeromaximo = 200000;
        int numerohilosProductores = 2;
        int numerohilosConsumidores = 4;
        CountDownLatch latch = new CountDownLatch(numerohilosConsumidores);
        ArrayList<Thread> producerThreads = new ArrayList<>();
        ArrayList<Thread> consumerThreads = new ArrayList<>();
        System.out.println("\n--- Iniciando Hilos Productores ---");
        int producerRangeSize = numeromaximo / numerohilosProductores;
        for (int i = 0; i < numerohilosProductores; i++) {
            int start = i * producerRangeSize + 1;
            int end = (i + 1) * producerRangeSize;
            if (i == numerohilosProductores - 1) {
                end = numeromaximo;
            }
            Thread producerThread = new Thread(new GeneradorHilos(numbersToVerifyQueue, start, end), "Producer-" + (i + 1));
            producerThreads.add(producerThread);
            producerThread.start();
        }
        System.out.println("\n--- Iniciando Hilos Consumidores ---");
        for (int i = 0; i < numerohilosConsumidores; i++) {
            Thread consumerThread = new Thread(new VerificadorHilos(numbersToVerifyQueue, listaPrimos, latch), "Consumer-" + (i + 1));
            consumerThreads.add(consumerThread);
            consumerThread.start();
        }
        for (Thread thread : producerThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Un hilo productor fue interrumpido: " + e.getMessage());
            }
        }
        System.out.println("\n--- Todos los Hilos Productores han terminado ---");
        try {
            for (int i = 0; i < numerohilosConsumidores; i++) {
                numbersToVerifyQueue.put(-1);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Error al enviar poison pill: " + e.getMessage());
        }
        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Espera de consumidores interrumpida: " + e.getMessage());
        }
        System.out.println("\n--- Todos los Hilos Consumidores han terminado ---");

        System.out.println("\n--- Resumen de la Aplicacion PrimeSecure (Generacion Concurrente) ---");
        System.out.println("Cantidad total de codigos primos genuinos en la base de datos: " + listaPrimos.getPrimesCount());

        System.out.println("--- APLICACION SAFE VOTE SYSTEM FINALIZADA ---");
    }
}